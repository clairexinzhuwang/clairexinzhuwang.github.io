Place the downloaded input files here. Nothing in this directory is tracked.
Check what you download against `../data_checksums.json`.
