# Round 10 manuscript synchronization

Generated main-text outputs:

- `figures/fig_fixedB_bka.pdf`
- `figures/simulation_summary_fixedB.tex`
- `figures/simulation_compact_main.tex`
- `figures/budget_ratio_main.tex`
- `figures/real_data_table_main.tex`

Generated supplementary outputs include the complete fixed-minibatch, omitted-component, runtime, finite-budget and without-replacement tables.

Rebuild from stored aggregate results:

```bash
python -u code/make_fixed_B_outputs.py
python -u code/make_realdata_table.py
python -u code/sync_figures.py <paper-source-directory>
```

Round 10 changes presentation terminology only: visible outputs use the stochastic-optimization component, optimization share, `v_opt` and the single tuple-budget ratio `Lambda_n=BT/n_1`. Internal result-frame columns such as `v_alg` and `alg_share` remain unchanged to preserve compatibility with the frozen replication records.

The earlier `B=512` finite-lambda pilot is retained only under
`archive/legacy_finite_lambda/`; it is not synchronized to the manuscript.
