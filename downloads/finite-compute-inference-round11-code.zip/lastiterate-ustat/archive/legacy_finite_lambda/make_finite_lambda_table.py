"""The budget-ratio table, generated from finite_lambda.json.

The reported grid fixes the schedule at T = (n/B) log2 n, so its budget ratio is
log2 n and grows with n.  The theorem, however, is stated for a finite limit of
BT/n as well, and that is the regime in which the optimization term is not
negligible.  This table runs the same kernel at fixed budget ratios so that the
regime the theorem is about is exercised directly.
"""
import json, os

import paths as P

SRC = os.path.join(P.RESULTS, "finite_lambda.json")
OUT = os.path.join(P.FIGURES, "finite_lambda_table.tex")


def main():
    rows = json.load(open(SRC))
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
             r"\begin{tabular}{rrrccccc}", r"\toprule",
             r"$\lambda$ & $T$ & $t_0$ & $\var_{\text{emp}}$ & $\var_{\text{dat}}$"
             r" & $\var_{\text{sgd}}$ & share & Cov.\\", r"\midrule"]
    for r in rows:
        share = r["var_sgd"] / (r["var_dat"] + r["var_sgd"])
        lines.append(
            f"{r['lam']:.1f} & {r['T']} & {r['t0']} & {r['var_emp']:.2e} & "
            f"{r['var_dat']:.2e} & {r['var_sgd']:.2e} & {share*100:.0f}\\% & "
            f"{r['coverage']:.3f}\\\\".replace("e-0", "e-"))
    lines += [r"\bottomrule", r"\end{tabular}",
              "\\caption{Smoothed rank regression at $n=10^4$ and $B=512$ with the "
              "horizon set from the budget ratio, $T$ being the nearest integer to $\\lambda n/B$, rather "
              "than from the schedule used elsewhere. $R=1000$ replications; the Monte "
              "Carlo standard error of a coverage near $0.95$ is about $0.007$. The last "
              "row is the ratio the reported grid happens to use at this sample size.}",
              r"\label{tab:finite-lambda}", r"\end{table}"]
    open(OUT, "w").write("\n".join(lines) + "\n")
    print(f"  wrote {OUT}")
    for r in rows:
        share = r["var_sgd"] / (r["var_dat"] + r["var_sgd"])
        print(f"    lambda={r['lam']:>5.1f}  coverage {r['coverage']:.3f}  "
              f"optimization share {share*100:.0f}%")


if __name__ == "__main__":
    main()
