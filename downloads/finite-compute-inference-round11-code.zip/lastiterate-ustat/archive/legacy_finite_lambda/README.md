# Legacy finite-lambda pilot

This directory preserves an earlier, unused budget-ratio pilot at `B=512`.
It is not referenced by the Round 10 manuscript and uses superseded notation.
The reported manuscript instead uses the fixed-`B=10` budget-ratio experiment
stored under `experiments_fixed_B`, with the single ratio `Lambda_n=BT/n_1`.
